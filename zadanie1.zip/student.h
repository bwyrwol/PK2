#ifndef STUDENT_H
#define STUDENT_H

#include <iostream>
#include <initializer_list>

//#define DEBUG

class student
{
private:
    char* nazwisko;

    int lancuch_dlugosc(const char* nazwisko);
    void lancuch_kopiuj(const char* zrodlo,
                        char* przeznaczenie);

public:
    student();
    student(const char* nazwisko);
    student(const std::initializer_list<char>& znaki);
    student(student& s);
    student(student&& s) noexcept;
    ~student();

    void ustaw_nazwisko(const char* nazwisko);
    char* odczytaj_nazwisko(void);
};

#endif//STUDENT_H