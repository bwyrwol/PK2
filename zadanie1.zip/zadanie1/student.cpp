#include "student.h"

int student::lancuch_dlugosc(const char* nazwisko)
{
    return 0;
}

void student::lancuch_kopiuj(const char* zrodlo, char* przeznaczenie)
{
}

student::student()
{
    nazwisko = NULL;
    std::cout << "Wywolany konstruktor student::student(), obiekt: " << this << std::endl;
}

student::~student()
{
    std::cout << "Wywolany destruktor student::~student(), obiekt: " << this << std::endl;
}

void student::ustaw_nazwisko(const char* nazwisko)
{

}
