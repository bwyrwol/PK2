﻿
#include <iostream>
#include "student.h"



int main()
{
    student student1;
    student student2;

    //ustaw_nazwisko("Nowak");

    std::cout << "Hello World!\n";
}

