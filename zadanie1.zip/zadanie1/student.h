#ifndef STUDENT_H
#define STUDENT_H

#include <iostream>

class student
{
private:
    char* nazwisko;

    int lancuch_dlugosc(const char* nazwisko);
    void lancuch_kopiuj(const char* zrodlo,
                        char* przeznaczenie);

public:
    student();
    //student();
    ~student();

    void ustaw_nazwisko(const char* nazwisko);
};

#endif//STUDENT_H