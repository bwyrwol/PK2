﻿
#include <iostream>
#include <initializer_list>
#include "student.h"

/*student domyslny_student()
{
    student domyslny("ANONIM");
    return domyslny;
}*/

int main()
{
    student student1;

    student1.ustaw_nazwisko("Nowak");
    std::cout << student1.odczytaj_nazwisko() << std::endl;
    student1.ustaw_nazwisko("Kowalski");
    std::cout << student1.odczytaj_nazwisko() << std::endl;

    student student2("Anonim");
    std::cout << student2.odczytaj_nazwisko() << std::endl;

    std::initializer_list<char> nazwisko3{'A','B','C',0};
    student student3(nazwisko3);
    std::cout << student3.odczytaj_nazwisko() << std::endl;

    student student4 = student2;
    std::cout << student4.odczytaj_nazwisko() << std::endl;

    student student5 = std::move(student1);
    std::cout << student5.odczytaj_nazwisko() << std::endl;
    //std::cout << student1.odczytaj_nazwisko() << std::endl;

    //student student6(domyslny_student());
    //std::cout << student6.odczytaj_nazwisko() << std::endl;

}

