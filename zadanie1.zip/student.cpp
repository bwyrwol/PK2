#include "student.h"

int student::lancuch_dlugosc(const char* nazwisko)
{
    int dlugosc = 0;
    while (nazwisko[++dlugosc] != 0)
    {
    }

    return dlugosc;
}

void student::lancuch_kopiuj(const char* zrodlo, char* przeznaczenie)
{
    for (int i = 0; i < lancuch_dlugosc(zrodlo) + 1; i++)
        przeznaczenie[i] = zrodlo[i];
}

student::student()
{
    nazwisko = NULL;

#ifdef DEBUG
    std::cout << ">>> Wywolany konstruktor student::student(), obiekt: " << this << std::endl;
#endif

}

student::student(const char* nazwisko)
{
    ustaw_nazwisko(nazwisko);
    std::cout << "Wywolany konstruktor student::student(const char* nazwisko), obiekt: " << this << std::endl;
}

student::student(const std::initializer_list<char>& znaki)
{
    nazwisko = new char[znaki.size() + 1];
    int i = 0;
    for (auto znak : znaki)
    {
        nazwisko[i++] = znak;
    }
    std::cout << "Wywolany konstruktor student::student(const std::initializer_list<char>& znaki), obiekt: " << this << std::endl;
}

student::student(student& s)
{
    ustaw_nazwisko(s.odczytaj_nazwisko());
    std::cout << "Wywolany konstruktor kopiujacy student::student(student& s), obiekt: " << this << std::endl;
}

student::student(student&& s) noexcept
{
    ustaw_nazwisko(s.odczytaj_nazwisko());
    delete[] s.nazwisko;
    s.nazwisko = nullptr;

    std::cout << "Wywolany konstruktor przenoszacy student::student(student& s), obiekt: " << this << std::endl;
}

student::~student()
{
    delete[] this->nazwisko;
    std::cout << "Wywolany destruktor student::~student(), obiekt: " << this << std::endl;
}

void student::ustaw_nazwisko(const char* nazwisko)
{
    //std::cout << lancuch_dlugosc(nazwisko) << std::endl;
    delete[] this->nazwisko;
    this->nazwisko = new char[lancuch_dlugosc(nazwisko) + 1];
    lancuch_kopiuj(nazwisko, this->nazwisko);
}

char* student::odczytaj_nazwisko(void)
{
    return nazwisko;
}
